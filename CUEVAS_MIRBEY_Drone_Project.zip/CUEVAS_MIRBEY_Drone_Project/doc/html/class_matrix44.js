var class_matrix44 =
[
    [ "determinant", "class_matrix44.html#aa04b9a3ed2ab380ba4aa3b91d514c4cd", null ],
    [ "m", "class_matrix44.html#a5fa44c68088fb376f652e59cf085b749", null ]
];