var class_matrix33 =
[
    [ "determinant", "class_matrix33.html#a91bdfd4a4ea7467fbb843761a830f090", null ],
    [ "get3x3From4x4", "class_matrix33.html#af5d566e26f06afb7937b70fc86d568dd", null ],
    [ "m", "class_matrix33.html#a78b7575191a5193b403a29a387ea9012", null ]
];