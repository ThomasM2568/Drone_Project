var annotated_dup =
[
    [ "Canvas", "class_canvas.html", "class_canvas" ],
    [ "Graph", "class_graph.html", "class_graph" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Matrix22", "class_matrix22.html", "class_matrix22" ],
    [ "Matrix33", "class_matrix33.html", "class_matrix33" ],
    [ "Matrix44", "class_matrix44.html", "class_matrix44" ],
    [ "myDrone", "classmy_drone.html", "classmy_drone" ],
    [ "MyPolygon", "class_my_polygon.html", "class_my_polygon" ],
    [ "Node", "class_node.html", "class_node" ],
    [ "server", "classserver.html", "classserver" ],
    [ "Triangle", "class_triangle.html", "class_triangle" ],
    [ "Vector2D", "class_vector2_d.html", "class_vector2_d" ],
    [ "Voronoi", "class_voronoi.html", "class_voronoi" ]
];