var hierarchy =
[
    [ "Graph", "class_graph.html", null ],
    [ "Matrix22", "class_matrix22.html", null ],
    [ "Matrix33", "class_matrix33.html", null ],
    [ "Matrix44", "class_matrix44.html", null ],
    [ "myDrone", "classmy_drone.html", null ],
    [ "MyPolygon", "class_my_polygon.html", null ],
    [ "Node", "class_node.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "Canvas", "class_canvas.html", null ]
    ] ],
    [ "server", "classserver.html", null ],
    [ "Triangle", "class_triangle.html", null ],
    [ "Vector2D", "class_vector2_d.html", null ],
    [ "Voronoi", "class_voronoi.html", null ]
];