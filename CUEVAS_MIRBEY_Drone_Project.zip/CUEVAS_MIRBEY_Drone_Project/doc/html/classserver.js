var classserver =
[
    [ "server", "classserver.html#ae034429a5a7b00634c6881444bccf38a", null ],
    [ "findNextHopToServer", "classserver.html#af5265227c7fb9f128d1a7d447d21f6cd", null ],
    [ "findShortestTransmissionPath", "classserver.html#abc4c0feb2f34e5b577fc00546741ec1b", null ],
    [ "color", "classserver.html#a8f1cea496680c1c05a482b24cc8e6f55", null ],
    [ "name", "classserver.html#ac2249051e11153735a620d82f93a272a", null ],
    [ "point", "classserver.html#a74138cc7926927023e14d0517d558fe4", null ],
    [ "y", "classserver.html#a2d42e5cfd564b8b3b6b63474097dc488", null ]
];