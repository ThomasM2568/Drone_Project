var searchData=
[
  ['vector2d_0',['Vector2D',['../class_vector2_d.html',1,'Vector2D'],['../class_vector2_d.html#ac55d52c97b338457bc3afb5d2f5e3344',1,'Vector2D::Vector2D(float p_x, float p_y)'],['../class_vector2_d.html#af29b5eef4648de62e98d19e0afa3c51e',1,'Vector2D::Vector2D(float p_x, float p_y, QString p_name)'],['../class_vector2_d.html#a98e9997ebb7a629f4db52397d4e0d653',1,'Vector2D::Vector2D()'],['../class_vector2_d.html#a93a8c1453c5de442266172d112cda946',1,'Vector2D::Vector2D(Vector2D *p)']]],
  ['velocity_1',['velocity',['../classmy_drone.html#ac363cebb8b9a9a7fdb53e8389d96002b',1,'myDrone']]],
  ['vertices_2',['vertices',['../class_canvas.html#a0ed3404d54fd67e188c9a35c6c0a0c2c',1,'Canvas']]],
  ['voronoi_3',['Voronoi',['../class_voronoi.html',1,'']]],
  ['voronoidone_4',['voronoiDone',['../class_canvas.html#ad704ed3392a81fde333e3c0ce5390d70',1,'Canvas']]]
];
