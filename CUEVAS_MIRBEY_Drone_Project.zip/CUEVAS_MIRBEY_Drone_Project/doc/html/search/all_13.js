var searchData=
[
  ['x_0',['x',['../class_node.html#a3a6b88b82c51d21305656d01e3c53039',1,'Node']]]
];
