var searchData=
[
  ['tabpoly_0',['tabPoly',['../class_voronoi.html#ac4bb9f624b3a0c8d33dcfeb8086018f5',1,'Voronoi']]],
  ['tabpts_1',['tabPts',['../class_my_polygon.html#a1a7d37fab752a1672ba3ae9b683c7f1c',1,'MyPolygon']]],
  ['takeoffspeed_2',['takeoffSpeed',['../classmy_drone.html#a8566368621b0f4b0862eb8778c280e8d',1,'myDrone']]],
  ['triangles_3',['triangles',['../class_canvas.html#aa3de99c5a524030b65b136f565879abd',1,'Canvas::triangles'],['../class_my_polygon.html#a2211051569fcfc71715284076980a832',1,'MyPolygon::triangles']]]
];
