var searchData=
[
  ['tabpoly_0',['tabPoly',['../class_voronoi.html#ac4bb9f624b3a0c8d33dcfeb8086018f5',1,'Voronoi']]],
  ['tabpts_1',['tabPts',['../class_my_polygon.html#a1a7d37fab752a1672ba3ae9b683c7f1c',1,'MyPolygon']]],
  ['takeoffspeed_2',['takeoffSpeed',['../classmy_drone.html#a8566368621b0f4b0862eb8778c280e8d',1,'myDrone']]],
  ['todo_20list_3',['Todo List',['../todo.html',1,'']]],
  ['triangle_4',['Triangle',['../class_triangle.html',1,'Triangle'],['../class_triangle.html#a27ba65a1d5db4b36848e3d6899e7ed36',1,'Triangle::Triangle(Vector2D *ptr1, Vector2D *ptr2, Vector2D *ptr3)'],['../class_triangle.html#af5042c1a552178df98b2e2317a24e803',1,'Triangle::Triangle(Vector2D *ptr1, Vector2D *ptr2, Vector2D *ptr3, const QColor &amp;p_color)']]],
  ['triangles_5',['triangles',['../class_canvas.html#aa3de99c5a524030b65b136f565879abd',1,'Canvas::triangles'],['../class_my_polygon.html#a2211051569fcfc71715284076980a832',1,'MyPolygon::triangles']]]
];
