var searchData=
[
  ['velocity_0',['velocity',['../classmy_drone.html#ac363cebb8b9a9a7fdb53e8389d96002b',1,'myDrone']]],
  ['vertices_1',['vertices',['../class_canvas.html#a0ed3404d54fd67e188c9a35c6c0a0c2c',1,'Canvas']]],
  ['voronoidone_2',['voronoiDone',['../class_canvas.html#ad704ed3392a81fde333e3c0ce5390d70',1,'Canvas']]]
];
