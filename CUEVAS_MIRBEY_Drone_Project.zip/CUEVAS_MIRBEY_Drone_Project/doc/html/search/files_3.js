var searchData=
[
  ['triangle_2ecpp_0',['triangle.cpp',['../triangle_8cpp.html',1,'']]],
  ['triangle_2eh_1',['triangle.h',['../triangle_8h.html',1,'']]]
];
