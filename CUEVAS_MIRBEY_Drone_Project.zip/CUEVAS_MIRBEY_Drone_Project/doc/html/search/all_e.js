var searchData=
[
  ['rescale_0',['reScale',['../class_canvas.html#a7c6aa7f3b2af6d97f2f9358d3e66951d',1,'Canvas']]],
  ['resizeevent_1',['resizeEvent',['../class_canvas.html#af6760030ef7aaf5cf73e89fbb55bee26',1,'Canvas']]],
  ['route_2',['route',['../classmy_drone.html#abbea6b8d34cc116c0fd156c6074aeec3',1,'myDrone']]],
  ['routeinitialized_3',['routeInitialized',['../classmy_drone.html#ae58db1a654b9490375e5b211daf0e270',1,'myDrone']]]
];
