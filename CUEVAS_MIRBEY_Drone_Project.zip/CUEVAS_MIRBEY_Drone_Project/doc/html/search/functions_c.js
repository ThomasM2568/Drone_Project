var searchData=
[
  ['rescale_0',['reScale',['../class_canvas.html#a7c6aa7f3b2af6d97f2f9358d3e66951d',1,'Canvas']]],
  ['resizeevent_1',['resizeEvent',['../class_canvas.html#af6760030ef7aaf5cf73e89fbb55bee26',1,'Canvas']]]
];
