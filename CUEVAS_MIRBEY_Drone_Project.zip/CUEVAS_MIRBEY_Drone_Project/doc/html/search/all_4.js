var searchData=
[
  ['edges_0',['edges',['../class_node.html#a120e57065e8bf8f37a615591fbcbda0c',1,'Node']]]
];
