var searchData=
[
  ['origin_0',['origin',['../class_canvas.html#a1cfc6518e39c51d16ff4f8c9ddfed909',1,'Canvas']]]
];
