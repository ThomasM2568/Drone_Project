var searchData=
[
  ['point_0',['point',['../classserver.html#a74138cc7926927023e14d0517d558fe4',1,'server']]],
  ['polygons_1',['polygons',['../class_canvas.html#a0f17d8b8a2c21433b47f011a47044d6d',1,'Canvas']]],
  ['position_2',['position',['../classmy_drone.html#a397b544944480dd220aa06e4abbc4f50',1,'myDrone']]],
  ['power_3',['power',['../classmy_drone.html#af7f353fb7dd6a17aedb45835acfc1ce5',1,'myDrone']]],
  ['powerconsumption_4',['powerConsumption',['../classmy_drone.html#a7e5a88588c7515265e1a7cf6a738ec7f',1,'myDrone']]],
  ['powerpb_5',['powerPB',['../classmy_drone.html#ad4ce2cb0f802f5f61f9776d71854f32c',1,'myDrone']]],
  ['ptr_6',['ptr',['../class_triangle.html#a06b229840845b947f4f9ded3585bea3b',1,'Triangle']]]
];
