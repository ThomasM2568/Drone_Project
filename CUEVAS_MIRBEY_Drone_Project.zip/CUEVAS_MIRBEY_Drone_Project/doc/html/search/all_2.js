var searchData=
[
  ['calculatecentroid_0',['calculateCentroid',['../class_my_polygon.html#a42ef482a4c8b9e5d86378037da96a2e8',1,'MyPolygon']]],
  ['canvas_1',['Canvas',['../class_canvas.html',1,'Canvas'],['../class_canvas.html#aeea65f2bfc2be61bdbcaaa3a67c33185',1,'Canvas::Canvas()']]],
  ['center_2',['center',['../class_my_polygon.html#ab2173c4b2b43c71100b43c9d33fb5035',1,'MyPolygon']]],
  ['chargingspeed_3',['chargingSpeed',['../classmy_drone.html#a24d340b3b048be7a6ec616b21e615edd',1,'myDrone']]],
  ['checkdelaunay_4',['checkDelaunay',['../class_canvas.html#a875b0b334afc2eb857604adddc118671',1,'Canvas::checkDelaunay()'],['../class_triangle.html#a6cd8236a25745922faf396bf4bbd6ded',1,'Triangle::checkDelaunay(const QVector&lt; Vector2D &gt; &amp;tabVertices)']]],
  ['checkisopen_5',['checkIsOpen',['../class_triangle.html#a35161ed8247d27691b99492961c16cb9',1,'Triangle']]],
  ['circlecontains_6',['circleContains',['../class_triangle.html#a9e8fb3bac838c95865165e61b14ee6bc',1,'Triangle']]],
  ['circumcenter_7',['circumCenter',['../class_triangle.html#a81b54984cefb55231f55bdfeac41a545',1,'Triangle']]],
  ['circumradius_8',['circumRadius',['../class_triangle.html#ab4b09de31bf414d3045d8b5a42fb9203',1,'Triangle']]],
  ['clear_9',['clear',['../class_canvas.html#ac4559a6535f497f17415032632aa9f6a',1,'Canvas']]],
  ['coefcollision_10',['coefCollision',['../classmy_drone.html#a113565f81df6f54ed92ddc6fda8a2ffc',1,'myDrone']]],
  ['color_11',['color',['../classmy_drone.html#a6ee5c5b591613309c02152ffa7eb72f8',1,'myDrone::color'],['../classserver.html#a8f1cea496680c1c05a482b24cc8e6f55',1,'server::color']]],
  ['compassize_12',['compasSize',['../classmy_drone.html#a7d79535260dee52d162326b08019d686',1,'myDrone']]],
  ['computecircle_13',['computeCircle',['../class_triangle.html#abc1d2380e0daf2b13ef96e3e89f01a2d',1,'Triangle']]],
  ['contains_14',['contains',['../class_triangle.html#aba5922794392893f80af8de5b75e582b',1,'Triangle']]],
  ['creategraph_15',['createGraph',['../class_main_window.html#afce1411fa5de59492a11b5d1a868ec51',1,'MainWindow']]],
  ['createpolygon_16',['createPolygon',['../class_canvas.html#ad17484a0449a61841e82a382000b39f9',1,'Canvas::createPolygon(const QVector&lt; Vector2D &gt; pointList)'],['../class_canvas.html#a8e31ca32966d8bb56b9cf542e211f72f',1,'Canvas::createPolygon(const QVector&lt; Vector2D &gt; pointList, QColor color)']]],
  ['createpolygonfromtriangles_17',['createPolygonFromTriangles',['../class_canvas.html#a782a2832d4457c3d7ad9319752008e16',1,'Canvas::createPolygonFromTriangles(const QVector&lt; Triangle * &gt; &amp;triangles, const Vector2D &amp;referencePoint)'],['../class_canvas.html#aac0f7138e4cfb3e6b62ad821c2aa5255',1,'Canvas::createPolygonFromTriangles(const QVector&lt; Triangle * &gt; &amp;sortedTriangles)']]],
  ['currentcolor_18',['currentColor',['../class_my_polygon.html#ab153cb2f23f6cb09aeb8cbcc4e8218fe',1,'MyPolygon']]],
  ['currentnodeindex_19',['currentNodeIndex',['../classmy_drone.html#a2b8bbcc8a1bbb10ae56e3ae560e24704',1,'myDrone']]]
];
