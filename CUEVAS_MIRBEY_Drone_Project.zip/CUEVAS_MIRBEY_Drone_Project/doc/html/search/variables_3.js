var searchData=
[
  ['damping_0',['damping',['../classmy_drone.html#ae4adfa7d5bfe57246abec186ddfd871a',1,'myDrone']]],
  ['direction_1',['direction',['../classmy_drone.html#a273b8b93aecdc9fddd0f88aed8331e6a',1,'myDrone']]],
  ['dronecollisiondistance_2',['droneCollisionDistance',['../class_canvas.html#a5226f7b0b1190ff98adb88f2f79c9b5c',1,'Canvas']]],
  ['dronemovement_3',['droneMovement',['../class_canvas.html#a47a0a36f99535fe7bee50862770e87cf',1,'Canvas']]],
  ['drones_4',['drones',['../class_canvas.html#a1313aae26271da4a783b0c6f6442750b',1,'Canvas']]]
];
