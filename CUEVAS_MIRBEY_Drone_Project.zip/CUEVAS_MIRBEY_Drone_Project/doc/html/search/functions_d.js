var searchData=
[
  ['server_0',['server',['../classserver.html#ae034429a5a7b00634c6881444bccf38a',1,'server']]],
  ['set_1',['set',['../class_vector2_d.html#a14a6cb145a9ac37b7242977b4d861040',1,'Vector2D']]],
  ['setcolor_2',['setColor',['../class_my_polygon.html#a8278555c2df2a71deb1ab38fe5a589b8',1,'MyPolygon::setColor()'],['../class_triangle.html#a9d9365aceb3f6e4f53867a0d37710cbb',1,'Triangle::setColor(const QColor &amp;p_color)']]],
  ['setdelaunay_3',['setDelaunay',['../class_triangle.html#a650fc423f2b682cc33b47c5313463406',1,'Triangle']]],
  ['setgoalposition_4',['setGoalPosition',['../classmy_drone.html#abf4b24ad01960a75230abd9709aa56a2',1,'myDrone::setGoalPosition(const Vector2D &amp;position)'],['../classmy_drone.html#afdf76fda1789e17abd885c47d10359d9',1,'myDrone::setGoalPosition(const QVector&lt; Vector2D &gt; &amp;serverList)']]],
  ['setgotoposition_5',['setGoToPosition',['../classmy_drone.html#a33103a690676633b4365c8f96f0064f5',1,'myDrone::setGoToPosition(const QVector&lt; Vector2D &gt; &amp;serverList)'],['../classmy_drone.html#a55ffd65fd07cfe6314c4dcb0d31ff404',1,'myDrone::setGoToPosition(Vector2D &amp;server)'],['../classmy_drone.html#afb5d7638cc28fe7b19b444d105675dea',1,'myDrone::setGoToPosition(Node *server)']]],
  ['sethighlighted_6',['setHighlighted',['../class_triangle.html#a1eaa6931e3451fb195f24a2c1da5f2fc',1,'Triangle']]],
  ['setinitialposition_7',['setInitialPosition',['../classmy_drone.html#a32ea0636ae4256bdfe10897d461a6f1c',1,'myDrone']]],
  ['setisactive_8',['setIsActive',['../classmy_drone.html#ae2a820b040457ba25441b5b73d40d2c1',1,'myDrone']]],
  ['setopposite_9',['setOpposite',['../class_triangle.html#a27f92765672968ee36819c38c377139b',1,'Triangle']]],
  ['setposition_10',['setPosition',['../classmy_drone.html#ae94af7580b88fef4adad471190f48f0f',1,'myDrone::setPosition(Node *server)'],['../classmy_drone.html#a785ac09d7fbdb544ae7630afd3b5a6d6',1,'myDrone::setPosition(int x, int y)']]],
  ['setroute_11',['setRoute',['../classmy_drone.html#afe65be1facefbf2540e100583732ed15',1,'myDrone']]],
  ['setspeed_12',['setSpeed',['../classmy_drone.html#adee6be6344d32e11a73c7a82cb58e02c',1,'myDrone']]],
  ['sortpointsbyangle_13',['sortPointsByAngle',['../class_canvas.html#ab3b332c167191ff90d5b60c6ee02d9f8',1,'Canvas']]],
  ['sorttrianglesbyleft_14',['sortTrianglesByLeft',['../class_canvas.html#af2416d857ebbf3aca6416f70976ba519',1,'Canvas']]],
  ['start_15',['start',['../classmy_drone.html#a5537d516c0a873688eb7b63c76e5e695',1,'myDrone']]],
  ['stop_16',['stop',['../classmy_drone.html#a68fd126455c1031c9a203388b67e15f0',1,'myDrone']]]
];
