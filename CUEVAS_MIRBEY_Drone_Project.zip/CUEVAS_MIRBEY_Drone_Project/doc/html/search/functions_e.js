var searchData=
[
  ['triangle_0',['Triangle',['../class_triangle.html#a27ba65a1d5db4b36848e3d6899e7ed36',1,'Triangle::Triangle(Vector2D *ptr1, Vector2D *ptr2, Vector2D *ptr3)'],['../class_triangle.html#af5042c1a552178df98b2e2317a24e803',1,'Triangle::Triangle(Vector2D *ptr1, Vector2D *ptr2, Vector2D *ptr3, const QColor &amp;p_color)']]]
];
