var searchData=
[
  ['_7ecanvas_0',['~Canvas',['../class_canvas.html#a237c4549ad2e27c729cd1f71e89f0fd9',1,'Canvas']]],
  ['_7emainwindow_1',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7emypolygon_2',['~MyPolygon',['../class_my_polygon.html#a94e1a0a9e8468dbf12073b5d12448106',1,'MyPolygon']]]
];
