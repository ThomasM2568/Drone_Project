var class_matrix22 =
[
    [ "determinant", "class_matrix22.html#ad18ae363d30a93115d9ac2fb53e6e71a", null ],
    [ "get2x2From3x3", "class_matrix22.html#a847e41917439faa7d5707bbf1332b5a0", null ],
    [ "m", "class_matrix22.html#af43a553822d93f8d38fdf057603be0ae", null ]
];